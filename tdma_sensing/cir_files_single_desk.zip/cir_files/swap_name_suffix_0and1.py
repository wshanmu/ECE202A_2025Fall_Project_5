import os
from pathlib import Path

def swap_node_names():
    """Swap Node0 and Node1 in filenames within the current folder and subdirectories."""
    current_folder = Path(__file__).parent
    
    # Find all files that contain Node0 or Node1 recursively
    files_to_rename = []
    for file_path in current_folder.rglob('*'):
        if file_path.is_file() and ('Node0' in file_path.name or 'Node1' in file_path.name):
            print(f"Found file to rename: {file_path}")
            files_to_rename.append(file_path)
    
    print(f"\nTotal files to rename: {len(files_to_rename)}\n")
    
    # Rename files using temporary names to avoid conflicts
    for file_path in files_to_rename:
        temp_name = file_path.with_name(file_path.name + '.tmp')
        file_path.rename(temp_name)
        print(f"Temp rename: {file_path.name} -> {temp_name.name}")
    
    # Perform the actual swap on all .tmp files recursively
    temp_files = list(current_folder.rglob('*.tmp'))
    print(f"\nSwapping Node0 <-> Node1 for {len(temp_files)} files...\n")
    
    for temp_file in temp_files:
        original_name = temp_file.name[:-4]  # Remove .tmp extension
        new_name = original_name.replace('Node0', 'TEMP_NODE')
        new_name = new_name.replace('Node1', 'Node0')
        new_name = new_name.replace('TEMP_NODE', 'Node1')
        
        final_path = temp_file.with_name(new_name)
        temp_file.rename(final_path)
        print(f"Renamed: {original_name} -> {new_name}")

if __name__ == '__main__':
    swap_node_names()